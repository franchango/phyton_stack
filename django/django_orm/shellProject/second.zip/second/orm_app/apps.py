from django.apps import AppConfig


class OrmAppConfig(AppConfig):
    name = 'orm_app'
