from django.apps import AppConfig


class AppPalabrasConfig(AppConfig):
    name = 'app_palabras'
