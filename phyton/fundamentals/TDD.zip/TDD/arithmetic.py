def take_square (num1):
    return (num1 * num1)