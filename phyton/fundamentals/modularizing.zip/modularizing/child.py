import parent

if __name__ == "__main__":
    print("El archivo esta siendo ejecutado directamente")
else:
    print(". El archivo se llama: ", __name__)
 